#pragma once
#include "CCEffect.h"
#include <regex>
#include <WinSock2.h>
#include "SimpleNullTerminatedTCPSocket.h"

class CCConnector
{
	SimpleNullTerminatedTCPSocket* connection = NULL;
	void OnTCPMessageCallbackReal(const char* message);
public:
	bool Connect();
	void AddEffect(std::regex* code_matcher, CCEffect* effect);
	bool hasError;
	char error[100];

};

