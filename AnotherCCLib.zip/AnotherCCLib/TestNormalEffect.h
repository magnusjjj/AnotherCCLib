#pragma once
#include "CCEffect.h"
class TestNormalEffect :
    public CCEffect
{
};

