#include "CCConnector.h"
#include <mutex>
#include "CCLock.h"
#include <functional>
#include <nlohmann/json.hpp>
using json = nlohmann::json;
#include "CCMessages.h"



/// <summary>
/// Tries to open communication with the crowd control server locally.
/// </summary>
/// <returns>Whether or not it was successful in connecting.</returns>

bool CCConnector::Connect()
{
	this->connection = new SimpleNullTerminatedTCPSocket();
	auto callback = std::bind(&CCConnector::OnTCPMessageCallbackReal, this, std::placeholders::_1);
	this->connection->SetMessageCallback(callback);
	return this->connection->Connect("localhost", "5420");
}



void CCConnector::OnTCPMessageCallbackReal(const char* message) {

	json data = json::parse(message);
	if (!data.is_object()){
		this->connection->_WARNING("Message from crowd control that wasn't an object: %s\n", message);
		return;
	}

	if (!data.contains("type") ) {
		this->connection->_WARNING("Message from crowd control that didn't contain a type field: %s\n", message);
		return;
	}

	switch ((uint8_t)data["type"]) {
		case CCRequestType::EffectStart:
			this->connection->_WARNING("A start of something nice: %s\n", message);
			break;
		default:
			this->connection->_WARNING("Unhandled message from crowd control: %s\n", message);
			break;
	}
	this->connection->_MESSAGE("HELLOOOO");
}


void CCConnector::AddEffect(std::regex* code_matcher, CCEffect* effect)
{
}

