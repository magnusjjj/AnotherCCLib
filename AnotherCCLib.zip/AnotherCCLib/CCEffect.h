#pragma once
#include <string>
#include <nlohmann/json.hpp>
#include <iostream>
using json = nlohmann::json;

template<typename T> class CCEffect
{
public:
	virtual CCEffect* CreateInstance() {
		return new T();
	};
};

class CCEffectInstance {
	CCEffect* type;
	std::string code;
	json message;
	void Respond();
};